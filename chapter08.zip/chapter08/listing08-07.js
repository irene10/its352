var years = [1855, 1648, 1420];
// remember that JavaScript statements can be
// spread across multiple lines for readability
var countries = [ "Canada", "France",
                  "Germany", "Nigeria",
                  "Thailand", "United States"];
// arrays can also be multi-dimensional ... notice the commas!
var month = [
   ["Mon","Tue","Wed","Thu","Fri"],
   ["Mon","Tue","Wed","Thu","Fri"],
   ["Mon","Tue","Wed","Thu","Fri"],
   ["Mon","Tue","Wed","Thu","Fri"]
];
// JavaScript arrays can contain different data types
var mess = [53, "Canada", true, 1420];