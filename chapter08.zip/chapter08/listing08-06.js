var count = 0;
while (count < 10) {
   // do something
   // ...
   count++;
}
count = 0;
do {
   // do something
   // ...
   count++;
} while (count < 10);